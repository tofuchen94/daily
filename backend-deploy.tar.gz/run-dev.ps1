# 本地开发启动脚本 - 连接远程 MySQL
# 在 PowerShell 中运行：.\run-dev.ps1

$env:DEV_MYSQL_HOST='106.13.109.237'
$env:DEV_MYSQL_USER='user1'
$env:DEV_MYSQL_PASSWORD='30wish4bqwsw!'

Write-Host "===================================" -ForegroundColor Green
Write-Host " 启动后端 - 连接远程 MySQL" -ForegroundColor Green
Write-Host "  Host: 106.13.109.237" -ForegroundColor Cyan
Write-Host "  User: user1" -ForegroundColor Cyan
Write-Host "  DB:   daily" -ForegroundColor Cyan
Write-Host "===================================" -ForegroundColor Green
Write-Host ""

mvn spring-boot:run
